#!/bin/bash

set -x
#

if [[ -z "${TIMEZONE}" ]]; then echo "TIMEZONE is unset";
else
echo "date.timezone = \"$TIMEZONE\"" > /etc/php.ini;
echo "date.timezone = \"$TIMEZONE\"" > /etc/php.ini;
fi

#check if TLS_REQCERT is present
if !(grep -q "TLS_REQCERT" /etc/openldap/ldap.conf)
then
	echo "TLS_REQCERT isn't present"
    echo -e "TLS_REQCERT\tnever" >> /etc/openldap/ldap.conf
fi


#/usr/libexec/httpd-ssl-gencerts

if [ -z "$(ls -A /etc/glpi)" ]; then
    cp -rap /root/config/* /etc/glpi/
fi

if [ -z "$(ls -A /var/lib/glpi/files)" ]; then
    cp -rap /root/files/* /var/lib/glpi/
fi

if [ $INSTALL -eq 0 ]; then
    rm -rf /var/www/html/glpi/install
fi


##################################################
cp -rp /tmp/plugins/* /var/www/html/glpi/plugins/
chmod +x /var/www/html/glpi/plugins/

#cp -rp /tmp/.htaccess //var/www/html/glpi/config/
cp -rp /tmp/downstream.php /var/www/html/glpi/inc/
cp -rp /tmp/local_define.php /etc/glpi/

## Move files workdir 

#cp -rap /var/www/html/glpi/files /root/files
#cp -rap /var/www/html/glpi/plugins /root/plugins
#cp -rap /var/www/html/glpi/marketplace /root/marketplace
#cp -rap /var/www/html/glpi/config /root/config

## move dir
#mkdir -p /etc/glpi
#cp -rap /root/config/* /etc/glpi/.
#cp -rap /root/files /var/lib/glpi

#chown -R apache:  /etc/glpi/ /var/lib/glpi/ /var/log/glpi/
#setenforce 0
#/usr/sbin/httpd -DFOREGROUND
/usr/sbin/php-fpm & /usr/sbin/httpd -D FOREGROUND
