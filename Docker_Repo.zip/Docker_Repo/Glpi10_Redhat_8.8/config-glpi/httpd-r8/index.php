<html>
<body>
<?php print "Bievenido a el sitio de Prueba, Docker Container Httpd!\n" ?>
</body>
</html>
